CREATE DATABASE cocobom;
USE cocobom;
CREATE TABLE usuario(
    id INT AUTO_INCREMENT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    login VARCHAR(20) NOT NULL,
    senha VARCHAR(20) NOT NULL,
    tipo INT(1) NOT NULL,
    PRIMARY KEY(Id)
);
INSERT INTO usuario (nome, login, senha, tipo) 
VALUES('Luciano Baginski', 'admin', 'senhasecreta', 0);
INSERT INTO usuario (nome, login, senha, tipo) 
VALUES('André Ricardo', 'potter', 'potter123', 1);

CREATE TABLE comentario(
    id INT AUTO_INCREMENT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    mensagem VARCHAR(255) NOT NULL,
    resposta INT NOT NULL,
    PRIMARY KEY(id)
);
INSERT INTO comentario (nome, email, mensagem, resposta) 
VALUES('Fulano de Tal', 'fulano@mail.com', 'Esta é uma mensagem de teste para ver se funciona.', 0);

CREATE TABLE produto(
    id INT AUTO_INCREMENT NOT NULL,
    codigo INT NOT NULL,
    titulo VARCHAR(20) DEFAULT 'Sabor não definido',
    sabor VARCHAR(50),
    ingredientes VARCHAR(100),
    preco decimal(10,2),
    imagem VARCHAR(50) DEFAULT '~/imagens/no-photo-240-0.png',
    PRIMARY KEY(id)
);
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12501, 'Amendoim', 'Bala recheada sabor amendoim', 'Ingredientes: água, açúcar, leite de coco, leite condensado e amendoim.', 10, '~/imagens/amendoim.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12502, 'Beijinho', 'Bala recheada sabor beijinho', 'Ingredientes: água, açúcar, leite de coco, leite condensado e coco ralado.', 10, '~/imagens/beijinho.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12503, 'Cereja', 'Bala recheada sabor cereja', 'Ingredientes: água, açúcar, leite de coco, leite condensado, fruta e corante.', 10, '~/imagens/cereja.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12504, 'Coco Queimado', 'Bala recheada sabor coco queimado', 'Ingredientes: água, açúcar, leite de coco, leite condensado e coco ralado torrado.', 10, '~/imagens/coco-queimado.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12505, 'Coco Tradicional', 'Bala de coco sem recheio', 'Ingredientes: água, açúcar, leite de coco.', 10, '~/imagens/coco-tradicional.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12506, 'Gengibre', 'Bala recheada sabor gengibre', 'Ingredientes: água, açúcar, leite de coco, leite condensado e gengibre desidratado.', 10, '~/imagens/gengibre.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12507, 'Leite Ninho', 'Bala recheada sabor leite ninho', 'Ingredientes: água, açúcar, leite de coco, leite condensado e leite em pó integral.', 10, '~/imagens/leite-ninho.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12508, 'Maracujá', 'Bala recheada sabor maracujá', 'Ingredientes: água, açúcar, leite de coco, leite condensado e maracujá desidratado.', 10, '~/imagens/maracuja.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12509, 'Morango', 'Bala recheada sabor morango', 'Ingredientes: água, açúcar, leite de coco, leite condensado e nesquick.', 10, '~/imagens/morango.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12510, 'Nozes', 'Bala recheada sabor nozes', 'Ingredientes: água, açúcar, leite de coco, leite condensado e nozes.', 10, '~/imagens/nozes.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12511, 'Nutella', 'Bala recheada sabor nutella', 'Ingredientes: água, açúcar, leite de coco, leite condensado, creme de leite e nutella.', 10, '~/imagens/nutella.jpeg');
INSERT INTO produto (codigo, titulo, sabor, ingredientes, preco, imagem) 
VALUES(12512, 'Prestígio', 'Bala recheada sabor prestígio', 'Ingredientes: água, açúcar, leite de coco, leite condensado, chocolate em pó e coco ralado.', 10, '~/imagens/prestigio.jpeg');
