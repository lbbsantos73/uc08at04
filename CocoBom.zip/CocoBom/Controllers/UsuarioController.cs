using CocoBom.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CocoBom.Controllers
{
    public class UsuarioController : Controller
    {
        public IActionResult Cadastro()
        {
            if (HttpContext.Session.GetInt32("idUsuario") == null)
                return RedirectToAction("Login"); 
            return View();
        }
        [HttpPost]
        public IActionResult Cadastro(Usuario u)
        {
            if (HttpContext.Session.GetInt32("tipoUsuario") == 0)
            {
                UsuarioRepository ur = new UsuarioRepository();
                ur.Incluir(u);
                ViewBag.Mensagem = "Usuário Cadastrado com sucesso";
            }
            else
            {
                ViewBag.Mensagem = "Somente administradores podem efetuar cadastro.";
            }
            return View();
        }
         public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Usuario u)
        {
            UsuarioRepository ur = new UsuarioRepository();
            Usuario usuario = ur.QueryLogin(u);
            if (usuario != null)
            {
                ViewBag.Mensagem = "Você está logado";
                HttpContext.Session.SetInt32("idUsuario", usuario.Id);
                HttpContext.Session.SetString("nomeUsuario", usuario.Nome);
                HttpContext.Session.SetInt32("tipoUsuario", usuario.Tipo);
                return View("Cadastro");
            }
            else
            {
                ViewBag.Mensagem = "Falha no Login";
                return View();
            }
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); //limpa toda a sessão
            ViewBag.Mensagem = "Você não está mais logado";
            return View("Login");
        }
        public IActionResult Listar()
        {
            if (HttpContext.Session.GetInt32("tipoUsuario") != 0)
            {
                ViewBag.Mensagem = "Somente administradores podem ver a listagem de usuários";
                return View("Login");
            }
            UsuarioRepository ur = new UsuarioRepository();
            List<Usuario> usuarios = ur.Query();
            return View(usuarios);
        }

        [HttpPost]
        public IActionResult Listar(int numId)
        {
            if (HttpContext.Session.GetInt32("tipoUsuario") != 0)
               return RedirectToAction("Login"); 
            UsuarioRepository ur = new UsuarioRepository();
            ur.Excluir(numId);
            List<Usuario> usuarios = ur.Query();
            return View(usuarios);
        }

        [HttpPost]
        public IActionResult Editar(int numId)
        {
            if (HttpContext.Session.GetInt32("tipoUsuario") != 0)
               return RedirectToAction("Login"); 
            UsuarioRepository ur = new UsuarioRepository();
            Usuario u= ur.QueryUsuario(numId);
            ViewBag.Id = u.Id;
            ViewBag.Nome = u.Nome;
            ViewBag.Login = u.Login;
            ViewBag.Senha = u.Senha;
            ViewBag.Tipo = u.Tipo;
            return View(u);
        }

        [HttpPost]
        public IActionResult Confirmar(Usuario u)
        {
            if (HttpContext.Session.GetInt32("tipoUsuario") == 0)
            {
                UsuarioRepository ur = new UsuarioRepository();
                ur.Atualizar(u);
                ViewBag.Mensagem = "Usuário Cadastrado com sucesso";
            }
            else
            {
                ViewBag.Mensagem = "Somente administradores podem efetuar cadastro.";
            }
            return View();
        }

        public IActionResult Inicio()
        {
            return View();
        }


    }
}