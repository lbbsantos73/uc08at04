using CocoBom.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CocoBom.Controllers
{
    public class ComentarioController : Controller
    {
        public IActionResult Fale_conosco()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Cadastro(Comentario c)
        {
            ViewData["Nome"] = "Nome: " + c.Nome;
            ViewData["email"] = "email: " + c.Email;
            ViewData["Mensagem"] = "Mensagem: " + c.Mensagem;
            ComentarioRepository cr = new ComentarioRepository();
            cr.Incluir(c);
            return View("Cadastro");
        }

        public IActionResult Listar()
        {
            if (HttpContext.Session.GetInt32("idUsuario") == null)
            {
                ViewBag.Mensagem = "Somente usuários logados podem ver a listagem de mensagens";
                return View("Login", "Usuario");
            }
            ComentarioRepository cr = new ComentarioRepository();
            List<Comentario> comentarios = cr.Query();
            return View(comentarios);
        }

        [HttpPost]
        public IActionResult Listar(int numId)
        {
            if (HttpContext.Session.GetInt32("idUsuario") == null)
               return RedirectToAction("Login", "Usuario"); 
            ComentarioRepository cr = new ComentarioRepository();
            cr.Excluir(numId);
            List<Comentario> comentarios = cr.Query();
            return View(comentarios);
        }

        [HttpPost]
        public IActionResult Editar(int numId)
        {
            if (HttpContext.Session.GetInt32("idUsuario") == null)
               return RedirectToAction("Login", "Usuario"); 
            ComentarioRepository cr = new ComentarioRepository();
            Comentario c= cr.QueryComentario(numId);
            ViewBag.Id = c.Id;
            ViewBag.Nome = c.Nome;
            ViewBag.Email = c.Email;
            ViewBag.Mensagem = c.Mensagem;
            ViewBag.Resposta = c.Resposta;
            return View(c);
        }

        [HttpPost]
        public IActionResult Confirmar(Comentario c)
        {
            if (HttpContext.Session.GetInt32("idUsuario") != null)
            {
                ComentarioRepository cr = new ComentarioRepository();
                cr.Atualizar(c);
                ViewBag.Mensagem = "Mensagem Cadastrada com sucesso";
            }
            else
            {
                ViewBag.Mensagem = "Somente usuários logados podem efetuar cadastro.";
            }
            return View();
        }

        public IActionResult Inicio()
        {
            return View();
        }

    }
}