using CocoBom.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CocoBom.Controllers
{
    public class ProdutoController : Controller
    {
        public IActionResult Cadastro()
        {
            if (HttpContext.Session.GetInt32("idUsuario") == null)
                return RedirectToAction("Login", "Usuario"); 
            return View();
        }
        
        [HttpPost]
        public IActionResult Cadastro(Produto p)
        {
            if (HttpContext.Session.GetInt32("tipoUsuario") == 0 || HttpContext.Session.GetInt32("tipoUsuario") == 1)
            {
                ProdutoRepository pr = new ProdutoRepository();
                pr.Incluir(p);
                ViewBag.Mensagem = "Produto Cadastrado com sucesso";
            }
            else
            {
                ViewBag.Mensagem = "Função não disponível.";
            }
            return View();
        }

         public IActionResult Listar()
        {
            ProdutoRepository pr = new ProdutoRepository();
            List<Produto> produtos = pr.Query();
            return View(produtos);
        }

       [HttpPost]
        public IActionResult Listar(int numId)
        {
            ProdutoRepository pr = new ProdutoRepository();
            pr.Excluir(numId);
            List<Produto> produtos = pr.Query();
            return View(produtos);
        }

        [HttpPost]
        public IActionResult Editar(int numId)
        {
            if (HttpContext.Session.GetInt32("idUsuario") == null)
               return RedirectToAction("Login","Usuario"); 
            ProdutoRepository pr = new ProdutoRepository();
            Produto p = pr.QueryProduto(numId);
            ViewBag.Id = numId;
            ViewBag.Codigo = p.Codigo;
            ViewBag.Titulo = p.Titulo;
            ViewBag.Sabor = p.Sabor;
            ViewBag.Ingredientes = p.Ingredientes;
            ViewBag.Preco = p.Preco;
            ViewBag.Imagem = p.Imagem;
            return View(p);
        }

        [HttpPost]
        public IActionResult Confirmar(Produto p)
        {
            if (HttpContext.Session.GetInt32("idUsuario") != null)
            {
                ProdutoRepository pr = new ProdutoRepository();
                pr.Atualizar(p);
                ViewBag.Mensagem = "Produto cadastrado com sucesso";
            }
            else
            {
                ViewBag.Mensagem = "Somente usuários cadastrados podem efetuar cadastro.";
            }
            return View();
        }

        public IActionResult Inicio()
        {
            return View();
        }

        public IActionResult descricao(int id)
        {
            ProdutoRepository pr = new ProdutoRepository();
            Produto prod = pr.QueryProduto(id);
            ViewBag.titulo = prod.Titulo;
            ViewBag.sabor = prod.Sabor;
            ViewBag.ingredientes = prod.Ingredientes;
            ViewBag.preco = "R$ " + prod.Preco;
            ViewBag.imagem = prod.Imagem;


            return View();
        }

         public IActionResult produtos()
        {
            ProdutoRepository pr = new ProdutoRepository();
            List<Produto> produtos = pr.Query();
            return View(produtos);
        }


    }
}