using MySqlConnector;
using System.Collections.Generic;

namespace CocoBom.Models
{
    public class ComentarioRepository
    {
        private const string _strConexao = "Database=cocobom;Data Source=127.0.0.1; User Id=root;";

        public void Excluir(int numId)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();

            string sql = "DELETE FROM comentario WHERE id = @ID";
            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@Id", numId);
            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public void Incluir(Comentario c)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();

            string sql = "INSERT INTO comentario (nome, email, mensagem, resposta)";
            sql = sql + " VALUES (@Nome, @Email, @Mensagem, @Resposta)";

            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@Nome", c.Nome);
            comando.Parameters.AddWithValue("@Email", c.Email);
            comando.Parameters.AddWithValue("@Mensagem", c.Mensagem);
            comando.Parameters.AddWithValue("@Resposta", c.Resposta);
            comando.ExecuteNonQuery();

            conexao.Close();
        }

        public void Atualizar(Comentario c)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();

            string sql = "UPDATE comentario set nome = @Nome,";
            sql = sql + " email = @Email, mensagem = @Mensagem, resposta = @Resposta WHERE id = @Id";

            MySqlCommand comando = new MySqlCommand(sql, conexao);
            comando.Parameters.AddWithValue("@Id", c.Id);
            comando.Parameters.AddWithValue("@Nome", c.Nome);
            comando.Parameters.AddWithValue("@Email", c.Email);
            comando.Parameters.AddWithValue("@Mensagem", c.Mensagem);
            comando.Parameters.AddWithValue("@Resposta", c.Resposta);
            comando.ExecuteNonQuery();

            conexao.Close();
        }

        public List<Comentario> Query()
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();
            string sql = "SELECT * FROM comentario";
            MySqlCommand comandoQuery = new MySqlCommand(sql, conexao);
            MySqlDataReader reader = comandoQuery.ExecuteReader();
            List<Comentario> lista = new List<Comentario>();
            while (reader.Read())
            {
                Comentario usr = new Comentario();
                usr.Id = reader.GetInt32("Id");

                if(!reader.IsDBNull(reader.GetOrdinal("Nome")))
                    usr.Nome = reader.GetString("Nome");
                if(!reader.IsDBNull(reader.GetOrdinal("Email")))
                    usr.Email = reader.GetString("Email");
                if(!reader.IsDBNull(reader.GetOrdinal("Mensagem")))
                    usr.Mensagem = reader.GetString("Mensagem");
                usr.Resposta = reader.GetInt32("Resposta");
                lista.Add(usr);
            }
            conexao.Close();
            return lista;
        }

         public Comentario QueryComentario(int ID)
        {
            MySqlConnection conexao = new MySqlConnection(_strConexao);
            conexao.Open();
            string sql = "SELECT * FROM comentario WHERE id = @ID";
            MySqlCommand comandoQuery = new MySqlCommand(sql, conexao);
            comandoQuery.Parameters.AddWithValue("@ID", ID);
            MySqlDataReader reader = comandoQuery.ExecuteReader();
            Comentario usr = null;
            if (reader.Read())
            {
                usr = new Comentario();
                usr.Id = reader.GetInt32("Id");
                if(!reader.IsDBNull(reader.GetOrdinal("Nome")))
                    usr.Nome = reader.GetString("Nome");
                if(!reader.IsDBNull(reader.GetOrdinal("Email")))
                    usr.Email = reader.GetString("Email");
                if(!reader.IsDBNull(reader.GetOrdinal("Mensagem")))
                    usr.Mensagem = reader.GetString("Mensagem");
                usr.Resposta = reader.GetInt32("Resposta");
            }
            conexao.Close();
            return usr;
        }

    }
}